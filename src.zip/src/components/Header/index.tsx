import { memo, useRef } from 'react';
import { Link } from 'react-router-dom';
import { useDetectOutsideClick } from '../../hooks/useDetectOutsideClick';
import { Sidebar } from '../Sidebar';
import museumLogoLight from '../../assets/logos/art-collection.png';
import homeIcon from '../../assets/icons/home-icon.svg';
import bookmarkIcon from '../../assets/icons/bookmark-light-orange-icon.svg';
import burgerIcon from '../../assets/icons/burger-icon.svg';
import { ROUTES } from '../../constants';
import { motion } from 'framer-motion';
import { useSparkNavigation } from '../../hooks/useSparkNavigation';

interface HeaderProps {
  isHomePage: boolean;
}

const HeaderComponent: React.FC<HeaderProps> = ({ isHomePage }) => {
  const sidebarRef = useRef(null);

  const { isVisible: sparkLogo, triggerSpark: sparkAndGoLogo } =
    useSparkNavigation();
  const { isVisible: sparkHome, triggerSpark: sparkAndGoHome } =
    useSparkNavigation();
  const { isVisible: sparkFav, triggerSpark: sparkAndGoFav } =
    useSparkNavigation();

  const handleSparkClick = (
    event: React.MouseEvent<HTMLAnchorElement>,
    targetPath: string,
    trigger: (path: string) => void,
  ) => {
    event.preventDefault();
    trigger(targetPath);
  };

  useDetectOutsideClick({
    ref: sidebarRef,
    isOpen: false,
    onClose: () => {},
  });

  return (
    <header className="header">
      <div className="wrapper">
        <Link
          to={ROUTES.home}
          onClick={e => handleSparkClick(e, ROUTES.home, sparkAndGoLogo)}
          className="header__navlist__link"
          style={{ position: 'relative', display: 'inline-block' }}
        >
          <img src={museumLogoLight} alt="Museum icon with museum title" />
          {sparkLogo && <Spark />}
        </Link>

        <nav className="header__nav">
          <ul className="header__navlist">
            {!isHomePage && (
              <li>
                <Link
                  to={ROUTES.home}
                  onClick={e =>
                    handleSparkClick(e, ROUTES.home, sparkAndGoHome)
                  }
                  className="header__navlist__link"
                  style={{
                    position: 'relative',
                    display: 'flex',
                    alignItems: 'center',
                  }}
                >
                  <img
                    src={homeIcon}
                    alt="Home icon"
                    style={{ width: 58, height: 58 }}
                  />
                  {sparkHome && <Spark />}
                  <span style={{ marginLeft: '6px' }}>Home</span>
                </Link>
              </li>
            )}
            <li>
              <Link
                to={ROUTES.favorites}
                onClick={e =>
                  handleSparkClick(e, ROUTES.favorites, sparkAndGoFav)
                }
                className="header__navlist__link"
                style={{
                  position: 'relative',
                  display: 'flex',
                  alignItems: 'center',
                }}
              >
                <img
                  src={bookmarkIcon}
                  alt="Bookmark icon"
                  style={{ width: 58, height: 58 }}
                />
                {sparkFav && <Spark />}
                <span style={{ marginLeft: '6px' }}>Favorites Gallery</span>
              </Link>
            </li>
          </ul>
        </nav>

        <button
          onClick={() => (document.body.style.overflow = 'hidden')}
          className="button button-burger"
        >
          <img src={burgerIcon} alt="Menu icon" />
        </button>
      </div>

      <Sidebar
        isHomePage={isHomePage}
        ref={sidebarRef}
        isOpen={false}
        onClose={() => (document.body.style.overflow = '')}
      />
    </header>
  );
};

const Spark: React.FC = () => (
  <motion.div
    initial={{ scale: 0, opacity: 1 }}
    animate={{ scale: 1.6, opacity: 0 }}
    transition={{ duration: 0.7, ease: 'easeOut' }}
    style={{
      position: 'absolute',
      top: '-4px',
      left: '-4px',
      width: '66px',
      height: '66px',
      borderRadius: '50%',
      backgroundColor: 'rgba(255, 200, 0, 0.6)',
      pointerEvents: 'none',
    }}
  />
);

export const Header = memo(HeaderComponent);
