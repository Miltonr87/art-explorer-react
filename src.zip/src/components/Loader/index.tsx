export const Loader: React.FC = () => {
  return (
    <div className="container">
      <span className="loader"></span>
    </div>
  );
};
